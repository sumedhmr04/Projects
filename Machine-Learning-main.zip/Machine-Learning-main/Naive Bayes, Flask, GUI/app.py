import pickle
from flask import Flask, request, jsonify
from flask_cors import CORS

# Initialize Flask app
app = Flask(__name__)
CORS(app)  # Enable CORS for cross-origin requests

# Load the models (update paths if needed)
with open(r'C:\Users\LENOVO\Desktop\Y4S1\ML\Assignment\4\models\naive_bayes_model.pkl', 'rb') as file:
    naive_bayes_model = pickle.load(file)

with open(r'C:\Users\LENOVO\Desktop\Y4S1\ML\Assignment\4\models\perceptron_model.pkl', 'rb') as file:
    perceptron_model = pickle.load(file)

# Define prediction route
@app.route('/predict', methods=['POST'])
def predict():
    data = request.get_json()  # Get JSON data from request

    # Extract and check input data
    try:
        glucose = float(data['Glucose'])
        insulin = float(data['Insulin'])
        bmi = float(data['BMI'])
        age = float(data['Age'])
        model_type = data.get('model', 'naive_bayes')  # Default to Naive Bayes if not specified
    except KeyError as e:
        return jsonify({'error': f'Missing field: {str(e)}'}), 400
    except ValueError:
        return jsonify({'error': 'Invalid data format'}), 400

    # Prepare input data for prediction
    input_data = [[glucose, insulin, bmi, age]]

    # Select model based on user input
    if model_type == 'perceptron':
        model = perceptron_model
    else:
        model = naive_bayes_model

    # Make prediction
    prediction = model.predict(input_data)

    # Return prediction as JSON
    return jsonify({'prediction': int(prediction[0])})

# Run the Flask app
if __name__ == '__main__':
    app.run(debug=True)
