from flask import Flask, render_template, request, redirect, session, jsonify
import hashlib
import random
import time
import os
import json

app = Flask(__name__)
app.secret_key = "secret_key_for_sessions"

# Zero Knowledge Proof Protocol
class ZeroKnowledgeProof:
    def __init__(self, p=11, g=2):
        self.p = p
        self.g = g

    def generate_proof(self, x):
        y = pow(self.g, x, self.p)
        r = random.randint(0, self.p - 2)
        h = pow(self.g, r, self.p)
        return y, r, h

    def verify_proof(self, y, r, h, b, s):
        lhs = pow(self.g, s, self.p)
        rhs = (h * pow(y, b, self.p)) % self.p
        return lhs == rhs

# Wallet class
class Wallet:
    def __init__(self):
        self.balances = {}

    def create_wallet(self, user):
        if user not in self.balances:
            self.balances[user] = 0
            return True
        return False

    def deposit(self, user, amount):
        self.balances[user] = self.balances.get(user, 0) + amount

    def withdraw(self, user, amount):
        if self.balances.get(user, 0) >= amount:
            self.balances[user] -= amount
            return True
        return False

    def get_balance(self, user):
        return self.balances.get(user, 0)

    def transfer(self, lender, borrower, amount):
        if self.balances.get(lender, 0) >= amount:
            self.balances[lender] -= amount
            self.balances[borrower] = self.balances.get(borrower, 0) + amount
            return True
        return False

# LoanRequest class
class LoanRequest:
    def __init__(self, borrower, amount):
        self.borrower = borrower
        self.amount = amount
        self.timestamp = time.time()

    def to_dict(self):
        return {"borrower": self.borrower, "amount": self.amount, "timestamp": self.timestamp}

    @staticmethod
    def from_dict(data):
        loan_request = LoanRequest(data["borrower"], data["amount"])
        loan_request.timestamp = data["timestamp"]
        return loan_request

# Blockchain class
class Blockchain:
    DATA_FILE = "blockchain_data.json"

    def __init__(self):
        self.loan_requests = []
        self.wallets = Wallet()
        self.chain = []
        self.load_data()

    def add_loan_request(self, borrower, amount):
        self.loan_requests.append(LoanRequest(borrower, amount))

    def get_loan_requests(self):
        return self.loan_requests

    def fulfill_loan_request(self, lender, borrower, amount):
        if lender == borrower:
            return False  # Prevent self-fulfilling requests
        if self.wallets.transfer(lender, borrower, amount):
            self.add_block({
                "lender": lender,
                "borrower": borrower,
                "amount": amount
            })
            self.loan_requests = [
                req for req in self.loan_requests
                if not (req.borrower == borrower and req.amount == amount)
            ]
            return True
        return False

    def add_block(self, transaction):
        previous_hash = self.chain[-1]["hash"] if self.chain else "0"
        block = {
            "index": len(self.chain) + 1,
            "timestamp": time.time(),
            "transactions": transaction,
            "previous_hash": previous_hash,
            "hash": self.compute_hash(transaction, previous_hash)
        }
        self.chain.append(block)

    def compute_hash(self, transaction, previous_hash):
        block_string = f"{transaction}{previous_hash}{time.time()}"
        return hashlib.sha256(block_string.encode()).hexdigest()

    def save_data(self):
        data = {
            "wallets": self.wallets.balances,
            "loan_requests": [req.to_dict() for req in self.loan_requests],
            "chain": self.chain
        }
        with open(self.DATA_FILE, "w") as f:
            json.dump(data, f)

    def load_data(self):
        if os.path.exists(self.DATA_FILE):
            with open(self.DATA_FILE, "r") as f:
                data = json.load(f)
                self.wallets.balances = data.get("wallets", {})
                self.loan_requests = [LoanRequest.from_dict(req) for req in data.get("loan_requests", [])]
                self.chain = data.get("chain", [])

blockchain = Blockchain()

@app.route("/")
def home():
    if "username" in session:
        return redirect("/dashboard")
    return render_template("login.html")

@app.route("/register", methods=["POST"])
def register():
    username = request.form.get("username")
    if blockchain.wallets.create_wallet(username):
        session["username"] = username
        return redirect("/dashboard")
    else:
        return "User already exists. Please log in."

@app.route("/login", methods=["POST"])
def login():
    username = request.form.get("username")
    if username in blockchain.wallets.balances:
        session["username"] = username
        return redirect("/dashboard")
    return "User does not exist. Please register first."

@app.route("/dashboard")
def dashboard():
    if "username" not in session:
        return redirect("/")
    username = session["username"]
    balance = blockchain.wallets.get_balance(username)
    loan_requests = [req for req in blockchain.get_loan_requests() if req.borrower != username]
    return render_template("dashboard.html", username=username, balance=balance, loan_requests=loan_requests)

@app.route("/logout")
def logout():
    session.pop("username", None)
    return redirect("/")

@app.route("/add_money", methods=["POST"])
def add_money():
    username = session["username"]
    amount = int(request.form.get("amount"))
    blockchain.wallets.deposit(username, amount)
    blockchain.save_data()
    return redirect("/dashboard")

@app.route("/borrow", methods=["POST"])
def borrow():
    username = session["username"]
    amount = int(request.form.get("amount"))
    blockchain.add_loan_request(username, amount)
    blockchain.save_data()
    return redirect("/dashboard")


@app.route("/fulfill", methods=["POST"])
def fulfill():
    lender = session["username"]
    borrower = request.form.get("borrower")
    amount = int(request.form.get("amount"))
    if blockchain.fulfill_loan_request(lender, borrower, amount):
        blockchain.save_data()
        return redirect("/dashboard")
    return "Error: Cannot fulfill this request."

@app.route("/blockchain")
def view_blockchain():
    if "username" not in session:
        return redirect("/")
    return render_template("blockchain.html", chain=blockchain.chain)


if __name__ == "__main__":
    app.run(debug=True)
