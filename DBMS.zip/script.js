document.getElementById("studentForm").addEventListener("submit", function(event) {
    event.preventDefault();

    const studentData = {
        student_id: document.getElementById("student_id").value,
        first_name: document.getElementById("first_name").value,
        last_name: document.getElementById("last_name").value,
        email: document.getElementById("email").value,
        branch: document.getElementById("branch").value,
        cgpa: document.getElementById("cgpa").value
    };

    fetch("/register_student", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(studentData)
    })
    .then(response => response.json())
    .then(data => alert(data.message))
    .catch(error => console.error("Error:", error));
});

document.getElementById("applicationForm").addEventListener("submit", function(event) {
    event.preventDefault();

    const applicationData = {
        student_id: document.getElementById("app_student_id").value,
        role_id: document.getElementById("role_id").value
    };

    fetch("/apply", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(applicationData)
    })
    .then(response => response.json())
    .then(data => alert(data.message))
    .catch(error => console.error("Error:", error));
});

function fetchRoles() {
    fetch("/roles")
    .then(response => response.json())
    .then(data => {
        let tableBody = document.querySelector("#rolesTable tbody");
        tableBody.innerHTML = "";
        data.forEach(role => {
            let row = `<tr>
                <td>${role.role_id}</td>
                <td>${role.role_title}</td>
                <td>${role.company_name}</td>
                <td>${role.base_salary}</td>
            </tr>`;
            tableBody.innerHTML += row;
        });
    })
    .catch(error => console.error("Error:", error));
}
