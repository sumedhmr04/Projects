CREATE TABLE student (
  student_id NUMBER PRIMARY KEY,
  first_name VARCHAR2(255),
  last_name VARCHAR2(255),
  address VARCHAR2(255),
  date_of_birth DATE,
  phone_number VARCHAR2(20),
  gender VARCHAR2(10),
  email VARCHAR2(255) UNIQUE,
  resume_link VARCHAR2(255),
  branch VARCHAR2(100),
  cgpa NUMBER(3, 2),
  skills CLOB
);

CREATE TABLE company (
  company_id NUMBER PRIMARY KEY,
  poc_id NUMBER,
  industry VARCHAR2(255),
  website VARCHAR2(255),
  address VARCHAR2(255),
  company_name VARCHAR2(255)
);

CREATE TABLE placement_unit (
  staff_id NUMBER PRIMARY KEY,
  company_id NUMBER,
  staff_name VARCHAR2(255),
  start_date DATE,
  capacity NUMBER
);

CREATE TABLE role (
  role_id NUMBER PRIMARY KEY,
  company_id NUMBER,
  role_title VARCHAR2(255),
  base_salary NUMBER(10, 2),
  job_description CLOB,
  preferred_skills CLOB,
  preferred_branch CLOB,
  application_deadline DATE,
  minimum_cgpa NUMBER(3, 2)
);

CREATE TABLE application (
  application_id NUMBER PRIMARY KEY,
  student_id NUMBER,
  company_id NUMBER,
  role_id NUMBER,
  status VARCHAR2(50),
  interview_date DATE,
  acceptance_deadline DATE,
  interview_notes CLOB,
  poc_id NUMBER
);

CREATE TABLE PS1 (
  student_id INT PRIMARY KEY,
  location VARCHAR(255),
  company_name VARCHAR(255),
  months_of_experience INT,
  FOREIGN KEY (student_id) REFERENCES student(student_id)
);
