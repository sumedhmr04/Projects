ALTER TABLE application ADD CONSTRAINT fk_application_student FOREIGN KEY (student_id) REFERENCES student(student_id);
ALTER TABLE application ADD CONSTRAINT fk_application_company FOREIGN KEY (company_id) REFERENCES company(company_id);
ALTER TABLE application ADD CONSTRAINT fk_application_role FOREIGN KEY (role_id) REFERENCES role(role_id);
ALTER TABLE application ADD CONSTRAINT fk_application_poc FOREIGN KEY (poc_id) REFERENCES placement_unit(staff_id);
ALTER TABLE placement_unit ADD CONSTRAINT fk_placement_unit_company FOREIGN KEY (company_id) REFERENCES company(company_id);
ALTER TABLE company ADD CONSTRAINT fk_company_poc FOREIGN KEY (poc_id) REFERENCES placement_unit(staff_id);
ALTER TABLE role ADD CONSTRAINT fk_role_company FOREIGN KEY (company_id) REFERENCES company(company_id);
