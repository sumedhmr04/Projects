UPDATE placement_unit SET company_id = 89 WHERE staff_id = 1029;
UPDATE placement_unit SET company_id = 76 WHERE staff_id = 1023;
UPDATE placement_unit SET company_id = 45 WHERE staff_id = 1039;
