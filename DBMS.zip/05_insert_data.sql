INSERT INTO student VALUES (1765, 'Naman', 'Jain', 'Address 1', TO_DATE('2003-05-06', 'YYYY-MM-DD'), '9835353721', 'M', 'f20211765@gmail.com', 'Link 1', 'A3', 9.5, 'Skills1');
INSERT INTO company (company_id, poc_id, industry, website, address, company_name) VALUES (89, 1029, 'IT', 'company2.com', 'Address 7', 'Company 2');
INSERT INTO placement_unit (staff_id, company_id, staff_name, start_date, capacity) VALUES (1029, 89, 'Larry', TO_DATE('2023-03-23', 'YYYY-MM-DD'), 3);
