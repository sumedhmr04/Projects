from flask import Flask, request, jsonify
import cx_Oracle

app = Flask(__name__)

dsn = cx_Oracle.makedsn("localhost", 1521, service_name="XE")
conn = cx_Oracle.connect(user="your_user", password="your_password", dsn=dsn)

@app.route('/register_student', methods=['POST'])
def register_student():
    data = request.json
    cursor = conn.cursor()
    try:
        cursor.execute("INSERT INTO student (student_id, first_name, last_name, email, branch, cgpa) VALUES (:1, :2, :3, :4, :5, :6)", 
                       (data['student_id'], data['first_name'], data['last_name'], data['email'], data['branch'], data['cgpa']))
        conn.commit()
        return jsonify({"message": "Student registered successfully"})
    except Exception as e:
        return jsonify({"error": str(e)})

@app.route('/apply', methods=['POST'])
def apply():
    data = request.json
    cursor = conn.cursor()
    try:
        cursor.execute("INSERT INTO application (student_id, role_id, status) VALUES (:1, :2, 'Pending')", 
                       (data['student_id'], data['role_id']))
        conn.commit()
        return jsonify({"message": "Application submitted successfully"})
    except Exception as e:
        return jsonify({"error": str(e)})

@app.route('/roles', methods=['GET'])
def get_roles():
    cursor = conn.cursor()
    cursor.execute("SELECT role_id, role_title, base_salary FROM role")
    roles = [{"role_id": row[0], "role_title": row[1], "base_salary": row[2]} for row in cursor.fetchall()]
    return jsonify(roles)

if __name__ == '__main__':
    app.run(debug=True)
