CREATE OR REPLACE TRIGGER check_salary_increase
BEFORE INSERT ON application
FOR EACH ROW
DECLARE
  prev_base_salary NUMBER;
  new_base_salary NUMBER;
BEGIN
  SELECT r.base_salary INTO new_base_salary FROM role r WHERE r.role_id = :NEW.role_id;
  SELECT MAX(r.base_salary) INTO prev_base_salary FROM application a JOIN role r ON a.role_id = r.role_id WHERE a.student_id = :NEW.student_id;

  IF prev_base_salary IS NOT NULL AND new_base_salary < prev_base_salary * 1.75 THEN
    RAISE_APPLICATION_ERROR(-20001, 'New application base salary must be at least 1.75 times the previous one.');
  END IF;
EXCEPTION
  WHEN NO_DATA_FOUND THEN NULL;
END;
/

CREATE OR REPLACE TRIGGER check_application_deadline
BEFORE INSERT ON application
FOR EACH ROW
DECLARE
  role_deadline DATE;
BEGIN
  SELECT r.application_deadline INTO role_deadline FROM role r WHERE r.role_id = :NEW.role_id;
  IF role_deadline IS NOT NULL AND SYSDATE > role_deadline THEN
    RAISE_APPLICATION_ERROR(-20001, 'Cannot apply for this role after the application deadline.');
  END IF;
END;
