CREATE OR REPLACE PROCEDURE proc1(stu_id IN INT) AS
  student_cg NUMBER(3,2);
  cg_cutoff NUMBER(3,2);
  student_branch VARCHAR(100);
  required_branch VARCHAR(300);
BEGIN
  SELECT s.cgpa, s.branch INTO student_cg, student_branch FROM student s WHERE s.student_id = stu_id;
  SELECT r.minimum_cgpa, r.preferred_branch INTO cg_cutoff, required_branch FROM application a, role r WHERE a.role_id = r.role_id AND a.student_id = stu_id;

  IF student_cg >= cg_cutoff THEN
    IF student_branch = required_branch THEN
      UPDATE application SET status = 'Approved' WHERE student_id = stu_id;
      DBMS_OUTPUT.PUT_LINE('This student is approved');
    ELSE
      UPDATE application SET status = 'Rejected' WHERE student_id = stu_id;
      DBMS_OUTPUT.PUT_LINE('This student is rejected');
    END IF;
  ELSE
    UPDATE application SET status = 'Rejected' WHERE student_id = stu_id;
    DBMS_OUTPUT.PUT_LINE('This student is rejected');
  END IF;
END;
/