SELECT a.application_id, s.first_name, s.last_name, r.role_title, r.base_salary, r.application_deadline, a.status
FROM application a
JOIN student s ON a.student_id = s.student_id
JOIN role r ON a.role_id = r.role_id
WHERE r.base_salary > 900000
ORDER BY r.base_salary DESC;

SELECT c.company_name, c.industry, c.website FROM company c
WHERE c.company_id NOT IN (SELECT DISTINCT a.company_id FROM application a);

SELECT s.first_name, s.last_name, COUNT(a.application_id) AS total_applications, MIN(a.interview_date) AS first_application_date, MAX(a.interview_date) AS last_application_date
FROM student s
JOIN application a ON s.student_id = a.student_id
GROUP BY s.student_id, s.first_name, s.last_name
HAVING (MAX(a.interview_date) - MIN(a.interview_date)) < 10;
