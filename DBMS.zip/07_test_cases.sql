INSERT INTO role (role_id, company_id, role_title, base_salary, job_description, preferred_skills, preferred_branch, application_deadline, minimum_cgpa) 
VALUES (150, 76, 'Project Manager', 750000.00, 'Planning, executing, and monitoring project activities', 'Project management, Communication, Leadership', 'A7', TO_DATE('2024-05-30', 'YYYY-MM-DD'), 8.0);

SELECT * FROM role;
EXEC proc1(1382);
SELECT * FROM application;
